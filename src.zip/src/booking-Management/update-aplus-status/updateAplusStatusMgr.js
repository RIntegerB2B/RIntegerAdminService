var updateAplusStatusDA = require('./updateAplusStatusDA');


exports.materialPickUpStatus = function (req, res) {
    try {
        updateAplusStatusDA.materialPickUpStatus(req, res)
   
    } catch (error) {
        console.log(error);
    }
}
exports.aplusShootPlanningStatus = function (req, res) {
    try {
        updateAplusStatusDA.aplusShootPlanningStatus(req, res)
   
    } catch (error) {
        console.log(error);
    }
}

exports.aplusShootStatus = function (req, res) {
    try {
        updateAplusStatusDA.aplusShootStatus(req, res)
   
    } catch (error) {
        console.log(error);
    }
}
exports.aplusProductDetailsStatus = function (req, res) {
    try {
        updateAplusStatusDA.aplusProductDetailsStatus(req, res)
   
    } catch (error) {
        console.log(error);
    }
}

exports.aplusPostProductionStatus = function (req, res) {
    try {
        updateAplusStatusDA.aplusPostProductionStatus(req, res)
   
    } catch (error) {
        console.log(error);
    }
}

exports.aplusProductDetailsStatus = function (req, res) {
    try {
        updateAplusStatusDA.aplusProductDetailsStatus(req, res)
   
    } catch (error) {
        console.log(error);
    }
}

exports.aplusLoginCredentialStatus = function (req, res) {
    try {
        updateAplusStatusDA.aplusLoginCredentialStatus(req, res)
   
    } catch (error) {
        console.log(error);
    }
}

exports.aplusContentStatus = function (req, res) {
    try {
        updateAplusStatusDA.aplusContentStatus(req, res)
   
    } catch (error) {
        console.log(error);
    }
}
exports.aplusCatalogUploadStatus = function (req, res) {
    try {
        updateAplusStatusDA.aplusCatalogUploadStatus(req, res)
   
    } catch (error) {
        console.log(error);
    }
}

exports.aplusQcProcessingStatus = function (req, res) {
    try {
        updateAplusStatusDA.aplusQcProcessingStatus(req, res)
   
    } catch (error) {
        console.log(error);
    }
}
exports.aplusInventoryStatus = function (req, res) {
    try {
        updateAplusStatusDA.aplusInventoryStatus(req, res)
   
    } catch (error) {
        console.log(error);
    }
}
exports.aplusProductLiveStatus = function (req, res) {
    try {
        updateAplusStatusDA.aplusProductLiveStatus(req, res)
   
    } catch (error) {
        console.log(error);
    }
}
exports.aplusPaymentStatus = function (req, res) {
    try {
        updateAplusStatusDA.aplusPaymentStatus(req, res)
   
    } catch (error) {
        console.log(error);
    }
}

exports.aplusMaterialReturnStatus = function (req, res) {
    try {
        updateAplusStatusDA.aplusMaterialReturnStatus(req, res)
   
    } catch (error) {
        console.log(error);
    }
}

