module.exports = {
    url: 'mongodb+srv://rinteger:admin@rinteger-z6qz7.mongodb.net/test?retryWrites=true&w=majority'
   /*  url: 'mongodb://52.66.167.224:27017/rinteger' */
}